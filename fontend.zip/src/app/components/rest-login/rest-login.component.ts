import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/utility/rest.service';

@Component({
  selector: 'app-rest-login',
  templateUrl: './rest-login.component.html',
  styleUrls: ['./rest-login.component.scss']
})
export class RestLoginComponent implements OnInit {

  constructor(private fb:FormBuilder, private _restService:RestService, private router:Router) { }

  loginForm:FormGroup=this.fb.group({       
    restaurantEmail:[''],
    restaurantPassword:['']  
  })
 

  onSubmit(){
    console.log(this.loginForm.value);
        this._restService.login(this.loginForm.value).subscribe(data=>{
      console.log(data);      
      console.log("Vaibhav1")
      alert("Restaurant Login Successful")
      this.router.navigateByUrl('restaurantHome');
      
    });        
  }

 
  // }
  ngOnInit(): void {
  }

}

