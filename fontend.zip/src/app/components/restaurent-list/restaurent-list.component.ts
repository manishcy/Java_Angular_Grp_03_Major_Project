import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Rest } from 'src/app/utility/rest';
import { UserServiceService } from 'src/app/utility/user-service.service';

@Component({
  selector: 'app-restaurent-list',
  templateUrl: './restaurent-list.component.html',
  styleUrls: ['./restaurent-list.component.scss']
})
export class RestaurentListComponent implements OnInit {

  rest!: Observable<Rest[]>;

  constructor(private userService: UserServiceService,private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.rest = this.userService.getrestaurentList();
  }

}
