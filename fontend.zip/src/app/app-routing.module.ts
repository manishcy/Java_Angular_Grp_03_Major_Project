import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminComponent } from './components/admin/admin.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';
import { RegisterUserComponent } from './components/register-user/register-user.component';
import { RestLoginComponent } from './components/rest-login/rest-login.component';
import { RestaurentListComponent } from './components/restaurent-list/restaurent-list.component';
import { RestaurentComponent } from './components/restaurent/restaurent.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { UserhomepageComponent } from './components/userhomepage/userhomepage.component';

const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:"home", component:HomeComponent},
  {path:"registration", component:RegisterUserComponent},
  {path:"login",component:LoginComponent},
  {path:"admin",component:AdminComponent},
  {path:"logout", component:LogoutComponent},
  {path:"restaurent", component:RestaurentComponent},
  {path:"user-list", component:UserListComponent},
  {path:"adminlogin", component:AdminLoginComponent},
  {path:"restlogin", component:RestLoginComponent},
  {path:"restlist", component:RestaurentListComponent},
  {path:"userhomepage", component:UserhomepageComponent},


  {path: '**', redirectTo: '' }
];

//    path: '', 
//   children: [
//     { path: '', component: HomeComponent },
//     { path: 'login', component: LoginComponent },
//     { path: 'login', component: LoginComponent },
//    ]
//   component: HomeComponent
// },      
// { path: 'logout', component: LogoutComponent },
// { path: '**', redirectTo: '' }
// ];




@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
