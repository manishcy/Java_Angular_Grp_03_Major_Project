export class Rest {
    rest_id!: number;
    restaurantName!: string;
    restaurantEmail!: string;
    address!: string;
  
}