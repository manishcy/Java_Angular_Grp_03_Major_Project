export class User {
    userId!: number;
    userName!: string;
    userMobileNo!: string;
    userEmail!: string;
    
}