export class User{
    userEmail!:string;
    userPassword!:string;
}