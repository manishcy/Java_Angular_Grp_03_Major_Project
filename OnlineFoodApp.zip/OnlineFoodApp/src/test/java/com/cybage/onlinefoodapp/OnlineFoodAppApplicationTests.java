package com.cybage.onlinefoodapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
