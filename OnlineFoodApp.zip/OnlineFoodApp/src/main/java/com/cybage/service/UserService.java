package com.cybage.service;

import java.util.List;

import com.cybage.model.User;

public interface UserService {
	public User saveUser(User user);	
	public List<User> findAllUsers();
	
}
