import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { User } from 'src/app/user';


@Injectable({
  providedIn: 'root'
})
export class UserloginService {

  //private baseUrl="http://localhost:8080/food-delivery/login";

  constructor(private _httpClient:HttpClient) { }

  // loginUser(user:User):Observable<object>{
  //   console.log(user);
  //   return this._httpClient.post<User>("http://localhost:8080/food-delivery/login",user)
  //  // return this._httpClient.post(`${this.baseUrl}`,user);
  // }


  //  loginUser(user:any){
  //    return this._httpClient.post<any>("http://localhost:8080/food-delivery/login", user);
  //  }
  loginUser(user:User) {
  
    return this._httpClient
      .post<any>(`http://localhost:8080/food-delivery/login`, user)

      .pipe(
        map(user => {
          // login successful if there's a user in the response
          if (user) {
            // store user details and basic auth credentials in local storage
            // to keep user logged in between page refreshes
            user.authdata = window.btoa(user);
            // user.authdata = window.btoa(userEmail + ":" + userPassword);
            localStorage.setItem("currentUser", JSON.stringify(user));
          }
          return User;
        })
      );
  }

  logout() {
    // remove user from local storage to log user out
    console.log(localStorage.getItem("currentuser"));
    localStorage.clear();
  }
}
 

