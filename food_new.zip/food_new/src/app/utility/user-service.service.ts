import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private _httpClient:HttpClient) { }

  registerUser(user:any){
    return this._httpClient.post<any>("http://localhost:8080/food-delivery/register", user);
  }
}
